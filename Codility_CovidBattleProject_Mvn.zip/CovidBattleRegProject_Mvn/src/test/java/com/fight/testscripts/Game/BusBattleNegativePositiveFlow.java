package com.fight.testscripts.Game;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fight.base.helper.InitializeDriver;
import com.fight.battlefield.page.factory.BusBattlePF;

public class BusBattleNegativePositiveFlow extends InitializeDriver {
	
	Boolean chkBusLink;
	
	@Test
	
	public void CheckBusBattle() throws InterruptedException
	{
		test=extent.createTest("Bus Battle in Covid","asd");
		
		BusBattlePF busBattle=PageFactory.initElements(driver, BusBattlePF.class);
		
		chkBusLink=busBattle.checkBusLink();
		test.log(Status.INFO, "Check the link for Bus");
		
		if(chkBusLink.equals(false))
		{
			test.log(Status.FAIL, "There is no Bus Link, please check the home page.");
			extent.removeTest(test);
			extent.flush();
			Assert.fail("No Bus Link found.");
		}
		
		busBattle.clickBusLink();
		test.log(Status.INFO, "Initializing the Bus Battle");
		
		busBattle.checkBusBattle();
		test.log(Status.PASS, "terminating the Bus Battle");
	}

}
