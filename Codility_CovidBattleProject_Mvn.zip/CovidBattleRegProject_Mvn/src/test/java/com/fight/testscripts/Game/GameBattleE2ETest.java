package com.fight.testscripts.Game;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fight.base.helper.InitializeDriver;
import com.fight.battlefield.page.factory.GamePF;

public class GameBattleE2ETest extends InitializeDriver {
	
	Boolean chkGameLink;
	
	@Test
	
	public void CheckBusBattle() throws InterruptedException
	{
		test=extent.createTest("Game Battle in Covid","Checking Game Battle Scenarios");
		
		GamePF busBattle=PageFactory.initElements(driver, GamePF.class);
		
		chkGameLink=busBattle.checkGameLink();
		test.log(Status.INFO, "Check the link for Game");
		
		if(chkGameLink.equals(false))
		{
			test.log(Status.FAIL, "There is no Game Link, please check the home page.");
			extent.removeTest(test);
			extent.flush();
			Assert.fail("No Game Link found.");
		}
		
		busBattle.clickGameLink();
		test.log(Status.INFO, "Initializing the Game Battle");
		
		busBattle.validGameBattle();
		test.log(Status.PASS, "Starting the Game Battle");
	}

}
