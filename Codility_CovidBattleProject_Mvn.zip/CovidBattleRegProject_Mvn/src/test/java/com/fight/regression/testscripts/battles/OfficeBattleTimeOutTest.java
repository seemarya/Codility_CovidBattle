package com.fight.regression.testscripts.battles;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fight.base.helper.InitializeDriver;
import com.fight.battlefield.page.factory.OfficePF;

public class OfficeBattleTimeOutTest extends InitializeDriver {
	
	Boolean chkOfficeLink;
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	
	public void OfficeBattleTimeOut() throws InterruptedException
	{
		test=extent.createTest("Office Battle Time Out test in Covid","Check the Office battle in Covid.");
		
		OfficePF officeBattle=PageFactory.initElements(driver, OfficePF.class);
		
		chkOfficeLink=officeBattle.checkOfficeLink();
		test.log(Status.INFO, "Check the link for Office");
		
		if(officeBattle.equals(false))
		{
			test.log(Status.FAIL, "There is no Office Link, please check the home page.");
			extent.removeTest(test);
			extent.flush();
			Assert.fail("No Office Link found.");
		}
		
		officeBattle.clickOfficeLink();
		test.log(Status.PASS, "Initializing the Office Battle");
		
		officeBattle.invalidOfficeBattle();
		test.log(Status.PASS, "Starting the Office Battle");
	}

}
