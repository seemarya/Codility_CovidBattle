package com.fight.regression.testscripts.battles;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fight.base.helper.InitializeDriver;
import com.fight.battlefield.page.factory.PublicPF;

public class PublicPlaceNegativeTest extends InitializeDriver {
	
	Boolean chkPublicLink;
	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	
	public void PublicBattleNegTest() throws InterruptedException
	{
		test=extent.createTest("Public Place Negative test Battle in Covid","Check the public battle in covid time.");
		
		PublicPF publicBattle=PageFactory.initElements(driver, PublicPF.class);
		
		chkPublicLink=publicBattle.checkPublicLink();
		test.log(Status.INFO, "Check the link for public place");
		
		if(publicBattle.equals(false))
		{
			test.log(Status.FAIL, "There is no public place Link, please check the home page.");
			extent.removeTest(test);
			extent.flush();
			Assert.fail("No public place Link found.");
		}
		
		publicBattle.clickPublicLink();
		test.log(Status.PASS, "Initializing the Public place Battle");
		
		publicBattle.checkPublicBattle();
		test.log(Status.PASS, "Starting the Public place Battle");
	}

}
