package com.fight.regression.testscripts.battles;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fight.base.helper.InitializeDriver;
import com.fight.battlefield.page.factory.BusBattlePF;

public class BusBattleE2ETest extends InitializeDriver {
	
	Boolean chkBusLink;
	
	@Test
	
	public void BusBattleE2E() throws InterruptedException
	{
		test=extent.createTest("Bus Battle End to End test in Covid","Check the bus battle in covid time.");
		
		BusBattlePF busBattle=PageFactory.initElements(driver, BusBattlePF.class);
		
		chkBusLink=busBattle.checkBusLink();
		test.log(Status.INFO, "Check the link for Bus");
		
		if(chkBusLink.equals(false))
		{
			test.log(Status.FAIL, "There is no Bus Link, please check the home page.");
			extent.removeTest(test);
			extent.flush();
			Assert.fail("No Bus Link found.");
		}
		
		busBattle.clickBusLink();
		test.log(Status.PASS, "Initializing the Bus Battle");
		
		busBattle.validBusBattle();
		
		test.log(Status.PASS, "Starting the Bus Battle");
	}

}
