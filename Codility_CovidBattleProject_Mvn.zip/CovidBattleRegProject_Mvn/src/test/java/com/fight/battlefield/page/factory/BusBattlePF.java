package com.fight.battlefield.page.factory;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fight.base.utility.PropertiesData;

public class BusBattlePF {

	WebDriver driver;
	WebDriverWait waitTime;
	
	static PropertiesData configFile = new PropertiesData();
	String user=configFile.getUserName();

	String[] valid_keywords= {"sanitizer","distancing","distance","report","elbow","research","yes","continue"};
	String[] invalid_keywords= {"peak","police","pretend","notice","ignore"};

	@FindBy(id="bus")
	WebElement busLink;

	@FindBy(id="staticBackdropLabel")
	WebElement initialPageTitle;

	@FindBy(xpath="//button[text()='Start']")
	WebElement start;

	@FindBy(xpath="//p[@class='option-label']")
	WebElement pageTitle;

	@FindBy(xpath="//h5[contains(text(),'That doesn't sound right!')]")
	WebElement warningText;
	
	@FindBy(id="close_incorrect_modal_btn")
	WebElement tryAgain;
	
	@FindBy(xpath="//span[@class='glyphicon glyphicon-home']")
	WebElement returnHome;

	@FindBy(xpath="//a[@class='btn text-wrap']")
	List<WebElement> options;

	@FindBy(xpath="//button[text()='Try the next battle']")
	WebElement nextBattle;

	@FindBy(id="score")
	WebElement score;
	
	@FindBy(id="leaderboard_link")
	WebElement chkScore;
	
	@FindBy(xpath="//button[@class='btn btn-secondary']")
	List<WebElement> invalidResp;
	
	@FindBy(xpath="//a[text()='Go to the leaderboard and check your score.']")
	List<WebElement> leaderboard;
	
	@FindBy(xpath=".//tr[td[contains(text(),'Seema')]]")
	WebElement totalScore;
	
	@FindBy(xpath="//p[text()='COVID-19 THE GAME - LEADERBOARD']")
	WebElement leaderboardTitle;
	
	//@FindBy(xpath="//span[text()=' Return Home']")
	//WebElement returnHome;
	
	public BusBattlePF(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}


	public boolean checkBusLink()
	{
		if(busLink.getText().equalsIgnoreCase("Take the bus"))
		{
			return true;
		}
		return false;
	}
	public void clickBusLink()
	{
		busLink.click();

		waitTime=new WebDriverWait(driver,Duration.ofSeconds(10));
		waitTime.until(ExpectedConditions.visibilityOf(initialPageTitle));

	}

	public void validBusBattle() throws InterruptedException
	{
		do
		{
			start.click();

			waitTime=new WebDriverWait(driver,Duration.ofSeconds(10));
			waitTime.until(ExpectedConditions.visibilityOf(pageTitle));

			for(WebElement e:options)
			{
				for(String a:valid_keywords)
				{
					if(e.getText().toLowerCase().contains(a))
					{
						System.out.println(e.getText());
						e.click();
						break;

					}

				}

			}
			waitTime.until(ExpectedConditions.visibilityOf(nextBattle));
			System.out.println(score.getText());
			System.out.println(nextBattle.getText());
			nextBattle.click();
		
		}
		while(!(leaderboard.size()>0));
		//while((invalidResp.size()>0));
		
		//while(!(tryAgain.size()>0));

		System.out.println("Check the leaderboard for score");
		start.click();
		leaderboard.get(0).click();
		System.out.println("Link clicked");
		waitTime.until(ExpectedConditions.visibilityOf(leaderboardTitle));
		System.out.println("Total score of: "+totalScore.getText());
		
	}

	public void invalidBusBattle() throws InterruptedException
	{
	
			start.click();

			waitTime=new WebDriverWait(driver,Duration.ofSeconds(25));
			waitTime.until(ExpectedConditions.visibilityOf(pageTitle));

			for(WebElement e:options)
			{
				for(String a:invalid_keywords)
				{
					if(e.getText().toLowerCase().contains(a))
					{
						System.out.println(e.getText());
						e.click();
						break;

					}

				}

			}
			
			//System.out.println(tryAgain.getText());
			waitTime.until(ExpectedConditions.visibilityOf(tryAgain));
			System.out.println("Inside try again");
			
			
			waitTime.until(ExpectedConditions.visibilityOf(returnHome));
			//System.out.println(timeOutText.getText());
			returnHome.click();
		
		
	}
	
	public void checkBusBattle() throws InterruptedException
	{
	
			start.click();

			waitTime=new WebDriverWait(driver,Duration.ofSeconds(25));
			waitTime.until(ExpectedConditions.visibilityOf(pageTitle));

			for(WebElement e:options)
			{
				for(String a:invalid_keywords)
				{
					if(e.getText().toLowerCase().contains(a))
					{
						System.out.println(e.getText());
						e.click();
						break;

					}

				}

			}
			
			//System.out.println(tryAgain.getText());
			waitTime.until(ExpectedConditions.visibilityOf(tryAgain));
			System.out.println("Inside try again");
			
			tryAgain.click();
			
			for(WebElement e:options)
			{
				for(String a:valid_keywords)
				{
					if(e.getText().toLowerCase().contains(a))
					{
						System.out.println(e.getText());
						e.click();
						break;

					}

				}

			}
			
			//System.out.println(tryAgain.getText());
			waitTime.until(ExpectedConditions.visibilityOf(nextBattle));
			System.out.println(score.getText());
			
			chkScore.click();
			
			waitTime.until(ExpectedConditions.visibilityOf(leaderboardTitle));
			System.out.println("Total score of: "+totalScore.getText());
		
		
	}

	
}
