package com.fight.base.utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class PropertiesData {
 
  Properties prop;
  
  public PropertiesData() {
	 
   try {
	File src=new File("./ConfigurationFile/config.properties");
	FileInputStream fis=new FileInputStream(src);
	prop=new Properties();
	prop.load(fis);
  }
  catch(Throwable t)
   {
	System.out.println("Exception is" +t.getStackTrace()); 
  }
}

 public String getBrowser() 
  {
	return prop.getProperty("Browser");  
  }
  
  public String getUrl() 
  {
	return prop.getProperty("URL");  
  }
  
  public String getUserName() 
  {
	return prop.getProperty("Username");  
  }
  
  public String getFilterUserName() 
  {
	return prop.getProperty("FilterUsername"); 
  }
  
  public String getPassword() 
  {
	return prop.getProperty("Password");  
  }
  
  public String getEmailAddress()
  {
	  return prop.getProperty("EmailAddress");
  }
  
  public String getFireFoxPath() 
  {
	return prop.getProperty("FirefoxDriverPath");  
  }
  
  public String getChromePath() 
  {
	return prop.getProperty("ChromeDriverPath");  
  }
  
  public String getIEPath() 
  {
	return prop.getProperty("IEDriverPath");  
  }
  
  public String getClientName() 
  {
	return prop.getProperty("ClientName");  
  }
  
  public String getCampaignName() 
  {
	return prop.getProperty("CampaignName");  
  }
  
  /*public String getFullPageScreenshotPath() 
  {
	return prop.getProperty("ErrorScreenshotPath");  
  }*/
  
  public String getReportsPath() 
  {
	return prop.getProperty("ReportsPath");  
  }
  
  public String getExcelPath() 
  {
	return prop.getProperty("ExcelFilePath");  
  }
  
  public String getErrorScreenshotPath() 
  {
	return prop.getProperty("ErrorScreenshotPath");  
  }
  
}

