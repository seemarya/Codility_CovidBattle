package com.fight.base.helper;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.Status;
import com.fight.base.page.factory.UserLoginPF;
import com.fight.base.utility.PropertiesData;


public class InitializeDriver extends BrowserFactory 
{

	static PropertiesData configFile = new PropertiesData();
	String ExpLoginTitle=" COVID-19 THE GAME ";
	String ExpButtonText="Start your journey ";
	String ExpHomeTitle="Choose your battle field ";
	String user=configFile.getUserName();

	@BeforeMethod
	public void FightLogin() 
	{
		test=extent.createTest("Covid -19 The Game", "Login to responsivefight application");
		UserLoginPF objLogin=PageFactory.initElements(BrowserFactory.driver, UserLoginPF.class);

		System.out.println("Login page title is: "+objLogin.getLoginTitle());
		test.log(Status.PASS, "Getting the Login title.");
		Assert.assertTrue(objLogin.getLoginTitle().equalsIgnoreCase(ExpLoginTitle));
		System.out.println("Login Title matched successfully");

		System.out.println("Logging into responsive fight application.");
	
		objLogin.loginToApp(user);
		test.log(Status.INFO, "Entered UserName");

		System.out.println("Login page button heading is: "+objLogin.checkButtonText());
		test.log(Status.INFO, "Checking the Login Button text.");
		Assert.assertTrue(objLogin.checkButtonText().equalsIgnoreCase(ExpButtonText+user));
		System.out.println("Button text matched successfully");

		objLogin.clickButton();
		test.log(Status.INFO, "Successfully landed to HomePage");

		System.out.println("Home page title is: "+objLogin.getHomePageTitle());
		test.log(Status.INFO, "Getting the HomePage title.");
		Assert.assertTrue(objLogin.getHomePageTitle().equalsIgnoreCase(ExpHomeTitle+user));
		System.out.println("Homepage Title matched successfully");


	}

	//	@BeforeTest
	//	public void HomePage()
	//	{
	//		test=extent.createTest("Covid -19 The Game", "HomePage Check");
	//		UserLoginPF objLogin=PageFactory.initElements(BrowserFactory.driver, UserLoginPF.class);
	//
	//		System.out.println("Home page title is: "+objLogin.getHomePageTitle());
	//		test.log(Status.INFO, "Getting the HomePage title.");
	//		Assert.assertTrue(objLogin.getHomePageTitle().equalsIgnoreCase(ExpHomeTitle+user));
	//		System.out.println("Homepage Title matched successfully");
	//		
	//	}


	@AfterMethod
	public void FightClose(){

		test=extent.createTest("responsive fight closing", "Closing the application");


		test.log(Status.PASS, "Successfully closing the application.");
		driver.close();
		
	}


}

