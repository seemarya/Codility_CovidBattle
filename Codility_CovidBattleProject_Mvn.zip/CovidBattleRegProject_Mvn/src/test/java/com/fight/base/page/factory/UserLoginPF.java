package com.fight.base.page.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UserLoginPF {
	
	WebDriver driver;
	
	String text = "Start your journey";

	String expHeading="COVID-19 THE GAME";
	
	@FindBy(xpath="//p[text()=' COVID-19 THE GAME ']")
	WebElement title_LoginPage;
	
	@FindBy(id="worrior_username")
	WebElement userName;
	
	@FindBy(id="warrior")
	WebElement createButton;
	
	@FindBy(id="start")
	WebElement checkBtnText;
	
	
	@FindBy(id="welcome_text")
	WebElement homePageHeading;
	
	
	
	public UserLoginPF(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public String getLoginTitle()
	{
		
		return title_LoginPage.getText();
		
	}
	
	public void loginToApp(String username)
	{
		//MiscUtilityFunctions MiscFunc = PageFactory.initElements(driver, MiscUtilityFunctions.class);
		userName.sendKeys(username);
		createButton.click();
		
	}
	
	public String checkButtonText()
	{
		return checkBtnText.getText();
	}
	
	public void clickButton()
	{
		checkBtnText.click();
	}
	
	public String getHomePageTitle()
	{
		return homePageHeading.getText();
	}

}
