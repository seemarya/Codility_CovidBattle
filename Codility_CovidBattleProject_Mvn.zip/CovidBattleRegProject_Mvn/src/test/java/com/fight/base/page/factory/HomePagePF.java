package com.fight.base.page.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePagePF {
	
	WebDriver driver;
	
	public HomePagePF(WebDriver driver)
	{
	
	this.driver=driver;
	}
	
	String expHeading="COVID-19 THE GAME";
	
	@FindBy(xpath="//p[@class='alpha-heading']")
	WebElement heading;
	
	public String checkHeading()
	{
		return heading.getText();
	}
	
}
