package com.fight.base.helper;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.fight.base.utility.PropertiesData;

public class TakeScreenShot {
	static PropertiesData configFile=new PropertiesData();
	
	public static String getScreenShot(WebDriver driver, String screenName) throws IOException
	{
		String dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
		//String dateFormat = new SimpleDateFormat("yyyy-MM-dd SSS").format(new Date());
		File scrFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String dest = System.getProperty("user.dir")+"//src//test//java//com//fight//result//screenshot//"+screenName+"_"+dateFormat+".png";
		File target = new File(dest);
		FileUtils.copyFile(scrFile, target);
		return dest;
	}

}
