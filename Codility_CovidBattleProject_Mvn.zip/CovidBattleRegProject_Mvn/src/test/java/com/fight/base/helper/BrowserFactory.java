package com.fight.base.helper;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.fight.base.utility.PropertiesData;

public class BrowserFactory {
	public static WebDriver driver;
	static PropertiesData configFile=new PropertiesData();
	public static String ExpectedLoginTitle="Digital Glue";
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;

	@BeforeClass
	public static void setup() {


		String projectPath = System.getProperty("user.dir");
		System.out.println("Project path is : "+projectPath);

		String BrowserName=configFile.getBrowser();
		if(BrowserName.equalsIgnoreCase("firefox")) 
		{
			//System.setProperty("webdriver.gecko.driver", projectPath+configFile.getFireFoxPath());
			System.setProperty("webdriver.gecko.driver", configFile.getFireFoxPath());

			//driver=new FirefoxDriver();
			DesiredCapabilities dcap = new DesiredCapabilities();
			dcap.setCapability("pageLoadStrategy", "normal");
			FirefoxOptions opt = new FirefoxOptions();
			opt.merge(dcap);
			driver = new FirefoxDriver(opt);

		}

		else if(BrowserName.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", projectPath+configFile.getChromePath());
			ChromeOptions cOptions = new ChromeOptions();
			//cOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			//cOptions.addArguments("--disable-infobars");
			cOptions.addArguments("--disable-extensions");
			// cOptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
			driver=new ChromeDriver(cOptions);
		}

		else if(BrowserName.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", projectPath+configFile.getIEPath());
			DesiredCapabilities capabilities=new DesiredCapabilities();
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			driver=new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(configFile.getUrl());

//		/************************Extent Report***************************************/
//		ExtentHtmlReporter htmlReporter=new ExtentHtmlReporter(projectPath+configFile.getReportsPath()+"/responsivefight.html");
//		extent=new ExtentReports();
//		extent.attachReporter(htmlReporter);
	}
	
	@BeforeTest
	public void startExtentReport()
	{
		String projectPath = System.getProperty("user.dir");
		ExtentHtmlReporter htmlReporter=new ExtentHtmlReporter(projectPath+configFile.getReportsPath()+"/responsivefight.html");
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
	}
	//@AfterMethod(dependsOnMethods="directLogout")
	@AfterMethod
	public void getResult(ITestResult result) throws IOException
	{
		if(result.getStatus()==ITestResult.SUCCESS)
		{
			test.pass(MarkupHelper.createLabel(result.getName()+"---> Test Case Passed", ExtentColor.GREEN));

		}
		else if(result.getStatus()==ITestResult.FAILURE)
		{
			test.fail(MarkupHelper.createLabel(result.getName()+"---> Test Case Failed", ExtentColor.RED));
			String screenshotPath=TakeScreenShot.getScreenShot(driver, result.getName());
			test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());

			test.fail(result.getThrowable());

			//test.log(Status.FAIL, test.addScreenCaptureFromPath(screenshotPath));
			//test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());

		}
		else
		{
			test.skip(MarkupHelper.createLabel(result.getName()+"---> Test Case Skipped", ExtentColor.YELLOW));
			test.skip(result.getThrowable());
		}
	}



	@AfterTest
	public static void tearDown()
	{
		extent.flush();
		System.out.println("Closing the Driver");
		//driver.close();
	}


}



