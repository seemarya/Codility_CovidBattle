package com.fight.base.page.factory;

import org.apache.commons.lang3.RandomStringUtils;

import com.fight.base.utility.PropertiesData;

public class MiscUtilityFunctions {
	
	static PropertiesData configFile=new PropertiesData();
	
public String genRandmNmbr(int length)
{
	return RandomStringUtils.randomNumeric(length);
}


}
